# Initialize Django
from djangoappengine.main import main

from google.appengine.ext.appstats.ui import main

if __name__ == '__main__':
    main()
