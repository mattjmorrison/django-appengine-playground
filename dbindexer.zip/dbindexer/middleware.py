from . import models

class DBIndexerMiddleware(object):
    """Empty because the import above already does everything for us"""
    pass
